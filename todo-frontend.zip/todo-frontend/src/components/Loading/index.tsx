import "./index.scss";

const Loading = () => {
  return <div className="loading"></div>;
};

export default Loading;
